@extends('layouts.app')

@section('app_content')

    <div class="section_404">
        <img src="/images/404.jpg" alt="404">
    </div>

@stop