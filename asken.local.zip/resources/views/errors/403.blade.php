@extends('layouts.app')

@section('app_content')

    <div class="section_403">
        <div class="fon"></div>
    </div>

@stop