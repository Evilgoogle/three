<!-- Delete -->
<div class="modal fade data_delete_modal" id="modal_delete" tabindex="-1" role="dialog" aria-labelledby="modal_delete">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">Вы уверены что хотите удалить?</div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal">Отмена</button>
                <button class="btn btn-primary js_confirm_delete">Удалить</button>
            </div>
        </div>
    </div>
</div>