<?php $__env->startSection('auth_content'); ?>

<div class="login-box">
    <div class="logo">
        <a href="/"><?php echo e(config('app.name')); ?></a>
    </div>
    <div class="card">
        <div class="body">
            <form id="sign_in" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="msg">Войти в систему</div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="material-icons">email</i>
                    </span>
                    <div class="form-line<?php echo e($errors->has('email') ? ' error' : ''); ?>">
                        <input id="email" type="email" class="form-control" name="email" placeholder="Email" required autofocus value="<?php echo e(old('email')); ?>">
                    </div>
                    <?php if($errors->has('email')): ?>
                        <label id="email-error" class="error" for="email"><?php echo e($errors->first('email')); ?></label>
                    <?php endif; ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="material-icons">lock</i>
                    </span>
                    <div class="form-line<?php echo e($errors->has('password') ? ' error' : ''); ?>">
                        <input type="password" class="form-control" name="password" placeholder="Пароль" required>
                    </div>
                    <?php if($errors->has('password')): ?>
                        <label id="password-error" class="error" for="password"><?php echo e($errors->first('password')); ?></label>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-xs-8 p-t-5">
                        <input type="checkbox" name="remember" id="remember" class="filled-in chk-col-pink">
                        <label for="remember">Запомнить меня</label>
                    </div>
                    <div class="col-xs-4">
                        <button class="btn btn-block bg-pink waves-effect" type="submit">Войти</button>
                    </div>
                </div>
                <div class="row m-t-15 m-b--20">
                    <div class="col-xs-12 align-right">
                        <a href="<?php echo e(url('/password/reset')); ?>">Забыли пароль?</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('auth.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>