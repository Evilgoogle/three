<?php $__env->startSection('app_content'); ?>


    <div class="main_block">
        <div class="pics">
            <?php $p = 0?>
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $p++?>
                <div id="main_<?php echo e($item->id); ?>" class="pic <?php echo e(($p == 1) ? 'active' : ''); ?>" style="background-image: url('/files/<?php echo e($item->image); ?>')"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="menu">
            <div class="contain">
                <?php $i = 0?>
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $i++?>
                    <a href="<?php echo e($item->url); ?>" class="bn <?php echo e(($i == 1) ? 'active' : ''); ?>" data-id="<?php echo e($item->id); ?>">
                        <div class="icon"><?php echo file_get_contents(asset('/files/'.$item->icon)); ?></div>
                        <h2 class="title"><?php echo e($item->title); ?></h2>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="bn stub"><span></span></div>
            </div>
        </div>
    </div>
    <div class="contain">
        <?php if(count($popular_cats)): ?>
            <section class="section_popularCats">
                <div class="headers h_love"><span>Популярные категории</span></div>
                <div class="block">
                    <?php $__currentLoopData = $popular_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="box">
                            <a href="/goods/<?php echo e($item->url); ?>" class="bn">
                                <div class="rubber">
                                    <div class="image" style="background-image: url(<?php echo e(issetImg($item->image)); ?>)"></div>
                                    <h3><?php echo e(str_limit($item->title, 28)); ?></h3>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
        <?php if(count($new_goods)): ?>
            <section class="section_new">
                <div class="headers h_new"><span>Новое на сайте</span></div>
                <div class="swiper_new">
                    <div class="contain">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $new_goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/goods_show/<?php echo e($item->url); ?>" class="swiper-slide good"style="background-image: url(<?php echo e(issetImg($item->image)); ?>)">
                                        <div class="box">
                                            <div class="m_top">
                                                <div class="mobile_image" style="background-image: url(<?php echo e(issetImg($item->image)); ?>)"></div>
                                                <div class="rubber">
                                                    <div class="text_content">
                                                        <h4><?php echo e(str_limit($item->title, 40)); ?></h4>
                                                        <div class="buy_elements">
                                                            <button type="button" class="buy js_buy" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                                            <button type="button" class="favourite js_favourite" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                                            <div class="link"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="m_bottom">
                                                <div class="buy_elements">
                                                    <button type="button" class="buy js_buy" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                                    <button type="button" class="favourite js_favourite" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                                    <div class="link"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <!-- Add Arrows -->
                    <div class="arrow swiper-button-next new-arrow-next"></div>
                    <div class="arrow swiper-button-prev new-arrow-prev"></div>
                </div>
            </section>
        <?php endif; ?>
        <?php if(count($popular_goods)): ?>
            <section class="section_popularGoods">
                <div class="headers h_love"><span>Популярные товары</span></div>
                <div class="swiper_popular-goods">
                    <div class="contain">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $popular_goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/goods_show/<?php echo e($item->url); ?>" class="swiper-slide good" style="background-image: url(<?php echo e(issetImg($item->image)); ?>)">
                                        <div class="box">
                                            <div class="m_top">
                                                <div class="mobile_image" style="background-image: url(<?php echo e(issetImg($item->image)); ?>)"></div>
                                                <div class="rubber">
                                                    <div class="text_content">
                                                        <h4><?php echo e(str_limit($item->title, 40)); ?></h4>
                                                        <div class="buy_elements">
                                                            <button type="button" class="buy js_buy" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                                            <button type="button" class="favourite js_favourite" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                                            <div class="link"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="m_bottom">
                                                <div class="buy_elements">
                                                    <button type="button" class="buy js_buy" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                                    <button  type="button" class="favourite js_favourite" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                                    <div class="link"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <!-- Add Arrows -->
                    <div class="arrow swiper-button-next new-popular-next"></div>
                    <div class="arrow swiper-button-prev new-popular-prev"></div>
                </div>
            </section>
        <?php endif; ?>
    </div>
    <div class="section_reviews">
        <div class="contain">
            <a href="/reviews" class="title"><span>FreeLife на YouTube</span></a>
            <?php if(count($reviews)): ?>
                <div class="block">
                    <div class="rubber">
                        <div class="left">
                            <div class="swiper_reviews swiper-container">
                                <div class="swiper-wrapper">
                                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="swiper-slide"><?php echo $item->video; ?></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="arrow">
                                    <div class="next swiper-button-next"></div>
                                    <div class="prev swiper-button-prev"></div>
                                </div>
                            </div>
                        </div>
                        <div class="right">
                            <?php $data = [];
                            foreach ($reviews as $js_items) {
                                $data[] = [
                                    'id' => $js_items->id,
                                    'title' => $js_items->title,
                                    'image' => $js_items->image
                                ];
                            }
                            $services_json = json_encode($data); ?>
                            <div class="reviews_pagination" data-blocks="<?php echo e($services_json); ?>"></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>