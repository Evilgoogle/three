<?php $__env->startSection('app_content'); ?>

    <?php
        $seo_new = (object)[];
        $seo_new->title = config('app.name').' | '.html_entity_decode($item->title);
        $seo_new->description = html_entity_decode(strip_tags($item->desc));
    ?>

<script type="application/ld+json">
{
    "@context": "https://schema.org/",
    "@type": "Product",
    "name": "<?php echo e(html_entity_decode($item->title)); ?>",
    <?php if(count($pics) > 0): ?>
    "image": [
        <?php $__currentLoopData = $pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            "<?php echo e(issetImg($p->image)); ?>"<?php echo e($loop->last ? '' : ','); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ],
    <?php endif; ?>
    "description": "<?php echo e(html_entity_decode(strip_tags($item->desc))); ?>",
    "offers": {
        "@type": "Offer",
        "url": "<?php echo e(url('goods_show/'.urlencode($item->url))); ?>",
        "priceCurrency": "KZT",
        <?php if(isset($item->discount) && $item->discount != 0): ?>
        "price": "<?php echo e($item->price); ?>",
        <?php $n_price = $item->price -(($item->price*$item->discount)/100);?>
        "price": "<?php echo e(round($n_price)); ?>"
        <?php else: ?>
        "price": "<?php echo e($item->price); ?>",
        <?php endif; ?>
        "seller": {
            "@type": "Organization",
            "name": "<?php echo e(config('app.name')); ?>"
        }
    }
}
</script>

    <div class="goods_show">
        <div class="contain">
            <h1 class="headers h_love"><span><?php echo e($item->title); ?></span></h1>
        </div>
        <div class="goods_info">
            <div class="contain">
                <div class="block">
                    <div class="left">
                        <?php if(isset($item->discount) && $item->discount != 0): ?>
                            <div class="icon discount"></div>
                        <?php endif; ?>        
                        <div class="swiper_goodshow swiper-container">
                            <div class="swiper-wrapper">
                                <?php if(count($pics)): ?>
                                    <?php $__currentLoopData = $pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="swiper-slide" style="background-image: url(<?php echo e(issetImg($p->image)); ?>)"></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="swiper-slide" style="background-image: url(<?php echo e(issetImg()); ?>)"></div>
                                <?php endif; ?>
                            </div>
                            <!-- Add Pagination -->
                            <!-- <div class="swiper-pagination"></div> -->
                            <div class="arrow swiper-button-next next"></div>
                            <div class="arrow swiper-button-prev prev"></div>
                        </div>
                    </div>
                    <div class="right">
                        <div class="info">
                            <div class="flex_block code_margin">
                                <div class="code">Код товара: <?php echo e($item->code); ?></div>
                                <div class="starts"></div>
                            </div>
                            <div class="flex_block">
                                <div class="love"></div>
                                <div class="available"><?php echo e($item->availability); ?></div>
                            </div>
                            <div class="parametrs">
                                <div class="bn delivery">
                                    <div class="item">доставка:</div>
                                    <div class="line"></div>
                                    <div class="info">бесплатная доставка, самовывоз</div>
                                </div>
                                <div class="bn">
                                    <div class="item">цвет:</div>
                                    <div class="line"></div>
                                    <div class="info"><?php echo e($item->color); ?></div>
                                </div>
                                <div class="bn">
                                    <div class="item">материал:</div>
                                    <div class="line"></div>
                                    <div class="info"><?php echo e($item->material); ?></div>
                                </div>
                                <div class="bn">
                                    <div class="item">артикул:</div>
                                    <div class="line"></div>
                                    <div class="info"><?php echo e($item->vendor_code); ?></div>
                                </div>
                            </div>
                            <div class="price_block">
                                <?php if(isset($item->discount) && $item->discount != 0): ?>
                                    <div class="flex_block">
                                        <div class="price">старая цена:</div>
                                        <div class="old"><?php echo e($item->price); ?>.-</div>
                                    </div>
                                    <?php $n_price = $item->price -(($item->price*$item->discount)/100)?>
                                    <div class="flex_block">
                                        <div class="price">Цена:</div>
                                        <div class="actual"><?php echo e(round($n_price)); ?>.-</div>
                                    </div>
                                <?php else: ?>
                                    <div class="flex_block">
                                        <div class="price">Цена:</div>
                                        <div class="actual"><?php echo e($item->price); ?>.-</div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <button class="busket js_buy" data-good_id="<?php echo e($item->id); ?>"><span>Добавить в корзину</span></button>
                            <button class="buy js_place_an_order" data-good_id="<?php echo e($item->id); ?>" data-right_away='on'><span>Купить сразу</span></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="contain">
            <section class="decs">
                <div class="headers h_text"><span>Описание</span></div>
                <div class="text"><?php echo e($item->desc); ?></div>
            </section>
            <?php if(count($view_goods)): ?>
                <section class="section_popularGoods">
                <div class="headers h_eye"><span>C этим товаром также смотрят:</span></div>
                <div class="swiper_popular-goods">
                    <div class="contain">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $view_goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $good): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/goods/<?php echo e($item->category_url); ?>/<?php echo e($good->url); ?>" class="swiper-slide good"style="background-image: url('/files/<?php echo e($good->image); ?>')">
                                        <div class="m_top">
                                            <div class="mobile_image" style="background-image: url('/files/<?php echo e($good->image); ?>')"></div>
                                            <div class="rubber">
                                                <div class="text_content">
                                                    <h4><?php echo e($good->title); ?></h4>
                                                    <div class="buy_elements">
                                                        <button class="buy js_buy"></button>
                                                        <button class="favourite js_favourite"></button>
                                                        <div class="link"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="m_bottom">
                                            <div class="buy_elements">
                                                <button class="buy js_buy" data-good_id="<?php echo e($good->id); ?>"></button>
                                                <button class="favourite js_favourite" data-good_id="<?php echo e($good->id); ?>"></button>
                                                <div class="link"></div>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <!-- Add Arrows -->
                    <div class="arrow swiper-button-next"></div>
                    <div class="arrow swiper-button-prev"></div>
                </div>
            </section>
            <?php endif; ?>
        </div>
        <section class="reviews">
            <div class="contain">
                <div class="headers"><span>Отзывы о товаре</span></div>
                <div class="block_reviews">
                    <div class="left">
                        <button class="js_comment" data-good_id="<?php echo e($item->id); ?>"><span>Добавить отзыв о товаре</span></button>
                    </div>
                    <div class="right">
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bn">
                                <div class="top">
                                    <div class="stars"></div>
                                    <div class="title"><?php echo e($cm->name); ?></div>
                                    <div class="date"><?php echo e($cm->created_at); ?></div>
                                </div>
                                <div class="bottom"><?php echo $cm->text; ?></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>