<div id="id-paginate" data-last-page="<?php echo e($paginate_view['total']); ?>"></div>

<?php $__currentLoopData = $get; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bn">
        <div class="column">
            <div class="rubber js_select" data-id="<?php echo e($item->id); ?>" data-name="<?php echo e($item->name); ?>" data-image="<?php echo e($item->image.setDinamic_image($item->id, isset($dinamic_images) ? $dinamic_images : [])); ?>" data-type="<?php echo e($item->type); ?>" data-alt="<?php echo e($item->alt); ?>" data-mass="<?php echo e($item->size); ?>" data-created_at="<?php echo e($item->created_at); ?>">
                <div class="image" style="background-image: url(/files/<?php echo e($item->image.setDinamic_image($item->id, isset($dinamic_images) ? $dinamic_images : [])); ?>)"></div>
                <div class="date"><?php echo e(date_vk($item->created_at)); ?></div>
                <div class="title"><?php echo e(str_limit($item->name, 24)); ?></div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

