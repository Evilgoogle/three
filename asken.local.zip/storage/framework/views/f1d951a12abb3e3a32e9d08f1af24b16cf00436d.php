<h2 class="card-inside-title"><?php echo e($label); ?> <?php echo e(isset($required) && $required ? '*' : ''); ?></h2>
<div class="row clearfix">
    <div class="col-sm-12">
        <div class="form-group">
            <div class="form-line">
                <?php if(!empty($item)): ?>
                    <?php if(isset($array) && $array && !empty($item)): ?>
                        <?php $name_new = substr($name, 0, -1) ?>
                        <table class="order-table images-table">
                            <tbody>
                            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="<?php echo e($i->id); ?>">
                                    <td class="index"><?php echo e($i->position); ?></td>
                                    <td>
                                        <div class="thumbnail" id="<?php echo e($i->id); ?>" data-model="<?php echo e($modelName); ?>" data-column="<?php echo e($name_new); ?>" data-remove="1">
                                            <a href="<?php echo e(asset('uploads/'. $i->$name_new)); ?>" target="_blank">
                                                <?php if(isset($is_image) && $is_image): ?>
                                                    <img src="<?php echo e(asset('uploads/'. $i->$name_new)); ?>" class="img-responsive">
                                                <?php else: ?>
                                                    <?php echo e($i->$name_new); ?>

                                                <?php endif; ?>
                                            </a>
                                            <button type="button" title="Удалить" class="btn btn-danger removeButton removeImage btn-xs">Удалить</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php elseif(!empty($item->$name)): ?>
                        <div class="thumbnail" id="<?php echo e($item->id); ?>" data-model="<?php echo e($modelName); ?>" data-column="<?php echo e($name); ?>" data-remove="0">
                            <a href="<?php echo e(asset('uploads/'. $item->$name)); ?>" target="_blank">
                                <?php if(isset($is_image) && $is_image): ?>
                                    <img src="<?php echo e(asset('uploads/'. $item->$name)); ?>" class="img-responsive">
                                <?php else: ?>
                                    <?php echo e($item->$name); ?>

                                <?php endif; ?>
                            </a>
                            <button type="button" title="Удалить" class="btn btn-danger removeButton removeImage btn-xs">Удалить</button>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <input
                    class="form-control"
                    type="file"
                    id="<?php echo e($name); ?>"
                    name="<?php echo e($name); ?><?php echo e(isset($array) && $array ? '[]' : ''); ?>"
                    <?php echo e(isset($required) && empty($item) && $required ? 'required' : ''); ?>

                    <?php echo e(isset($array) && $array ? 'multiple' : ''); ?>

                    <?php echo e(isset($disabled) && $disabled ? 'disabled' : ''); ?>>
            </div>
        </div>
    </div>
</div>
