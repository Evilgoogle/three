<h2 class="card-inside-title"><?php echo e($label); ?> <?php echo e(isset($required) && $required ? '*' : ''); ?></h2>
<div class="row clearfix">
    <div class="col-sm-12">
        <div class="form-group">
            <div class="form-line">
                <select
                    class="form-control show-tick"
                    id="<?php echo e($name); ?>"
                    name="<?php echo e($name); ?><?php echo e(isset($array) && $array ? '[]' : ''); ?>"
                    title="<?php echo e($label); ?>"
                    <?php echo e(isset($search) && $search ? 'data-live-search="true"' : ''); ?>

                    <?php echo e(isset($required) && $required ? 'required' : ''); ?>

                    <?php echo e(isset($array) && $array ? 'multiple' : ''); ?>

                    <?php echo e(isset($disabled) && $disabled ? 'disabled' : ''); ?>>
                    <?php if(!empty($options)): ?>
                        <?php if(isset($none) && $none): ?>
                            <option value="0">Нет</option>
                        <?php endif; ?>
                        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($o->$oKey); ?>" <?php echo e($selectedId == $o->$oKey ? 'selected' : ''); ?>><?php echo e($o->$oValue); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
        </div>
    </div>
</div>