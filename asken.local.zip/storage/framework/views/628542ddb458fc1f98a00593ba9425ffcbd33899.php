<?php $__env->startSection('admin_content'); ?>

<input type="hidden" id="ajaxUrl" value="<?php echo e($info->url); ?>">
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">
            <div class="header">
                <h2><?php echo e($info->head); ?></h2>
                <a href="/admin/<?php echo e($info->url); ?>/add" class="btn btn-info waves-effect m-t-15">Добавить</a>
            </div>
            <div class="body table-responsive">
                <table class="table table-bordered table-striped js-table dataTable">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Страница</th>
                        <th>URL</th>
                        <th>Опции</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="<?php echo e($item->id); ?>">
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->page); ?></td>
                            <td><a href="<?php echo e($item->url != 'main' ? url('/'. $item->url) : url('/')); ?>" target="_blank"><?php echo e($item->url); ?></a></td>
                            <td>
                                <a href="/admin/<?php echo e($info->url); ?>/edit/<?php echo e($item->id); ?>">Изменить</a>
                                <?php if($item->url != 'main'): ?>
                                    <a href="/admin/<?php echo e($info->url); ?>/remove/<?php echo e($item->id); ?>">Удалить</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>