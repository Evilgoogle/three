<?php $__env->startSection('admin_content'); ?>

    <input type="hidden" id="ajaxUrl" value="<?php echo e($info->url); ?>">
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <h2>Заявка</h2>
                </div>
                <div class="body">
                    <form action="/admin/<?php echo e($info->url); ?>/insert<?php echo e(isset($item->id) ? '/'. $item->id : ''); ?>" method="post">
                        <?php echo e(csrf_field()); ?>


                        <?php if($item->enable == false): ?>
                            <?php echo $__env->make('admin._input.input-switch', [
                                'name' => 'enable',
                                'label' => 'Статус',
                                'item' => isset($item) ? $item : '',
                                'default' => true,
                                'on' => 'Обработан', 'off' => 'Не обработан'
                            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endif; ?>

                        <?php echo $__env->make('admin._input.input-text', [
                            'name' => 'name',
                            'label' => 'Имя',
                            'item' => isset($item) ? $item : '',
                            'disabled' => true
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php echo $__env->make('admin._input.input-text', [
                            'name' => 'phone',
                            'label' => 'Телефон',
                            'item' => isset($item) ? $item : '',
                            'disabled' => true
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php echo $__env->make('admin._input.input-text', [
                            'name' =>  'email',
                            'label' => 'E-mail',
                            'item' => isset($item) ? $item : '',
                            'disabled' => true
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php echo $__env->make('admin._input.textarea', [
                            'name' => 'message',
                            'label' => 'Текст',
                            'item' => isset($item) ? $item : '',
                            'disabled' => true
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php if(!$item->enable): ?>
                            <div class="row clearfix">
                                <div class="col-sm-12">
                                    <button type="submit" class="btn btn-primary m-t-10 waves-effect"><?php echo e(isset($item) ? 'Обновить' : 'Записать'); ?></button>
                                </div>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>