<!DOCTYPE html>
<html>
<body>
    <b>Есімі:</b> <?php echo e(isset($data['name']) ? $data['name'] : ''); ?><br>
    <b>Телефоны:</b> <?php echo e(isset($data['phone']) ? $data['phone'] : ''); ?><br>
    <b>Почтасы:</b> <?php echo e(isset($data['email']) ? $data['email'] : ''); ?><br>
    <b>Сауал:</b> <?php echo isset($data['quest']) ? $data['quest'] : ''; ?>

</body>
</html>