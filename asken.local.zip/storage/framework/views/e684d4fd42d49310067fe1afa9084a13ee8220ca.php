<?php $__env->startSection('admin_content'); ?>

    <input type="hidden" id="ajaxUrl" value="<?php echo e($info->url); ?>">
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <h2><?php echo e($info->head); ?></h2>
                    <a href="/admin/<?php echo e($info->url); ?>/add" class="btn btn-info waves-effect m-t-15">Добавить</a>
                </div>
                <div class="body table-responsive">
                    <table class="table table-bordered table-striped js-table order-table">
                        <thead>
                        <tr>
                            <th class="index">Порядок сортировки</th>
                            <th>ID</th>
                            <th>Заголовок</th>
                            <th>Иконка</th>
                            <th>Дата добавление</th>
                            <th>Опции</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="<?php echo e($item->id); ?>">
                                <td class="index"><?php echo e($item->order); ?></td>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><img src="<?php echo e(issetImg($item->icon)); ?>" class="goods_preview"></td>
                                 <td><?php echo e($item->created_at); ?></td>
                                <td>
                                    <a href="/admin/<?php echo e($info->url); ?>/edit/<?php echo e($item->id); ?>" class="entry_edit btn btn-default"><i class="fas fa-edit"></i> <span>изменить</span></a>
                                    <a href="/admin/<?php echo e($info->url); ?>/remove/<?php echo e($item->id); ?>" class="js_del_data entry_del btn btn-primary"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>