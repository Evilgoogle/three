<?php $__env->startSection('app_content'); ?>

    <div class="gallary page">
        <div class="contain">
            <div class="swiper_gallary">
                <?php if($items->count()): ?>
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide" style="background-image: url('/files/<?php echo e($item->image); ?>')">
                                    <div class="content">
                                        <h2><?php echo e($item->title); ?></h2>
                                        <small><?php echo e($item->desc); ?></small>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="arrows">
                        <div class="prev swiper-button-next"></div>
                        <div class="next swiper-button-prev"></div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>