<div class="bn">
    <div class="column">
        <div class="rubber js_select blue" data-id="<?php echo e($set->id); ?>" data-name="<?php echo e($set->name); ?>" data-image="<?php echo e($set->image); ?>" data-type="<?php echo e($set->type); ?>" data-alt="<?php echo e($set->alt); ?>" data-mass="<?php echo e($set->size); ?>" data-created_at="<?php echo e($set->created_at); ?>">
            <div class="image" style="background-image: url(/files/<?php echo e($set->image); ?>)"></div>
            <div class="date"><?php echo e(date_vk($set->created_at)); ?></div>
            <div class="title"><?php echo e(str_limit($set->name, 24)); ?></div>
        </div>
    </div>
</div>