<ul class="pagination">
    <?php if($total != 1): ?>
        <li class="page-item prev">
            <a class="page-link" href="<?php echo e(($patch === null) ? Request::url().'/?page='.($_GET['page']-1) : $patch.'&page='.($_GET['page']-1)); ?>" rel="prev">Назад</a>
        </li>
    <?php endif; ?>

    <li class="page-item one_element<?php echo ($page == 1) ? 'active' : ''?>">
        <a class="page-link" href="<?php echo e(($patch === null) ? Request::url().'/?page=1' : $patch.'&page=1'); ?>">1</a>
    </li>

    <?php if($page == 1 || $page == 2 || $page == 3 || $page == 4): ?>
        <?php
        if($total > 8) {
            $set = 9;
        } else {
            $set = $total;
        }
        ?>
        <?php for($count = 2; $count < $set; $count++): ?>
            <li class="page-item <?php echo ($count == $page) ? 'active' : ''?>">
                <a class="page-link" href="<?php echo e(($patch === null) ? Request::url().'/?page='.($count) : $patch.'&page='.($count)); ?> "><?php echo e($count); ?></a>
            </li>
        <?php endfor; ?>
    <?php elseif($page > 4): ?>
        <?php
        if($page == 5) {
            $num = 4;
        } else {
            $num = 3;
        }
        if(($page+3) > $total) {
            $sum = $total - $page;
        } else {
            $sum = 3;
        }
        ?>
        <li class="page-item disabled"><a class="page-link" href="">...</a></li>
        <?php for($count = $num; $count >= 1; $count--): ?>
            <?php if(($page-$count) != 1): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e(($patch === null) ? Request::url().'/?page='.($page-$count) : $patch.'&page='.($page-$count)); ?>"><?php echo e($page-$count); ?></a></li>
            <?php endif; ?>
        <?php endfor; ?>
        <li class="page-item active"><a class="page-link" href="<?php echo e(($patch === null) ? Request::url().'/?page='.($page) : $patch.'&page='.($page)); ?>"><?php echo e($page); ?></a></li>
        <?php for($count = 1; $count <= $sum; $count++): ?>
            <li class="page-item"><a class="page-link" href="<?php echo e(($patch === null) ? Request::url().'/?page='.($page+$count) : $patch.'&page='.($page+$count)); ?>"><?php echo e($page+$count); ?></a></li>
        <?php endfor; ?>
    <?php endif; ?>

    <?php if($total != 1): ?>
        <li class="page-item disabled"><a class="page-link" href="">...</a></li>
        <li class="page-item last_element<?php echo ($page == $total) ? 'active' : ''?>">
            <a class="page-link" href="<?php echo e(($patch === null) ? Request::url().'/?page='.$total : $patch.'&page='.$total); ?>"><?php echo e($total); ?></a>
        </li>

        <li class="page-item next">
            <a class="page-link" href="<?php echo e(($patch === null) ? Request::url().'/?page='.($_GET['page']+1) : $patch.'&page='.($_GET['page']+1)); ?>" rel="next">Вперед</a>
        </li>
    <?php endif; ?>
</ul>