<?php $__env->startSection('app_content'); ?>

    <div class="main_swiper swiper-container">
        <?php $data = [];
        foreach ($main as $js_items) {
            $data[] = [
                'id' => $js_items->id,
                'title' => $js_items->title,
                'icon' => $js_items->icon
            ];
        }
        $main_json = json_encode($data); ?>
        <div class="swiper-wrapper">
            <?php $__currentLoopData = $main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <!-- text -->
                    <div class="contain">
                        <div class="content">
                            <h2><?php echo e($item->title); ?></h2>
                            <small><?php echo e($item->desc); ?></small>
                            <a href="/catalog/<?php echo e($item->url); ?>" class="web_button"></a>
                        </div>
                    </div>

                    <!-- absolute -->
                    <div class="fon">
                        <div class="zoomer" id="main_fon_<?php echo e($item->id); ?>">
                            <div data-depth="0.2" class="element" style="background-image: url('/files/<?php echo e($item->fon); ?>')"></div>
                        </div>
                    </div>
                    <div class="image" id="main_image_<?php echo e($item->id); ?>">
                        <div data-depth="0.2" class="element" style="background-image: url('/files/<?php echo e($item->image); ?>')"></div>
                    </div>
                    <div class="main_swiper_panel">
                        <div class="arrows">
                            <div class="prev swiper-button-next"></div>
                            <div class="next swiper-button-prev"></div>
                        </div>
                        <div class="block" data-blocks="<?php echo e($main_json); ?>"></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>