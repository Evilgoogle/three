<?php $__env->startSection('app_content'); ?>

    <div class="product">
        <div class="bn">
            <div class="box man">
                <a href="/goods/man" class="title">Man</a>
                <div class="block">
                    <?php $__currentLoopData = $man; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/goods/<?php echo e($item->url); ?>" class="link"><?php echo e($item->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="#" class="more"><span></span></a>
                </div>
            </div>
        </div>
        <div class="bn">
            <div class="box woman">
                <a href="/goods/woman" class="title">Woman</a>
                <div class="block">
                    <?php $__currentLoopData = $woman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/goods/<?php echo e($item->url); ?>" class="link"><?php echo e($item->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="#" class="more"><span></span></a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>