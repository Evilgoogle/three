<h2 class="card-inside-title"><?php echo e($label); ?> <?php echo e(isset($required) && $required ? '*' : ''); ?></h2>
<div class="row clearfix">
    <div class="col-sm-12">
        <?php if(!empty($item)): ?>
            <?php if(isset($array) && $array && !empty($item)): ?>
                <?php $name_new = substr($name, 0, -1) ?>
                <table class="order-table images-table">
                    <tbody>
                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="<?php echo e($i->id); ?>">
                            <td class="index"><?php echo e($i->order); ?></td>
                            <td>
                                <div class="thumbnail">
                                    <a href="<?php echo e(issetImg($i->$name_new)); ?>" target="_blank">
                                        <?php if(isset($is_image) && $is_image): ?>
                                            <img src="<?php echo e(issetImg($i->$name_new)); ?>" class="img-responsive">
                                        <?php else: ?>
                                            <?php echo e($i->$name_new); ?>

                                        <?php endif; ?>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php elseif(!empty($item->$name)): ?>
                <div class="thumbnail">
                    <a href="<?php echo e(issetImg($item->$name)); ?>" target="_blank">
                        <?php if(isset($is_image) && $is_image): ?>
                            <img src="<?php echo e(issetImg($item->$name)); ?>" class="img-responsive">
                        <?php else: ?>
                            <?php echo e($item->$name); ?>

                        <?php endif; ?>
                    </a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <div class="panel panel-default">
            <div class="panel-heading"><button type="button" class="btn btn-default filemanager_open" data-basic_id="<?php echo e($filemanager_id); ?>">Выбрать</button></div>
            <div class="panel-body">
                <div id="filemanager_create_<?php echo e($filemanager_id); ?>" class="filemanager_create"></div>
                <input type="hidden" id="filemanager_server_image_<?php echo e($filemanager_id); ?>" name="<?php echo e($name); ?>" value="<?php echo e(!empty($item) ? $item->$name : ''); ?>">
            </div>
        </div>
    </div>
</div>