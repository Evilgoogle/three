<h2 class="card-inside-title"><?php echo e($label); ?> <?php echo e(isset($required) && $required ? '*' : ''); ?></h2>
<div class="row clearfix">
    <div class="col-sm-12">
        <div class="form-group">
            <div class="form-line">
                <textarea
                    class="form-control <?php echo e(isset($editor) && $editor ? 'text-editor' : ''); ?><?php echo e(isset($editor_type) && $editor_type ? '-'.$editor_type : ''); ?>"
                    id="<?php echo e($name); ?>"
                    name="<?php echo e($name); ?><?php echo e(isset($array) && $array ? '[]' : ''); ?>"
                    placeholder="<?php echo e($label); ?>"
                    <?php echo e(isset($required) && $required ? 'required' : ''); ?>

                    <?php echo e(isset($array) && $array ? 'multiple' : ''); ?>

                    <?php echo e(isset($disabled) && $disabled ? 'disabled' : ''); ?>><?php if (isset($editor) && $editor) {?><?php echo isset($item->$name) ? $item->$name : ''; ?><?php } else {?><?php echo e(isset($item->$name) ? $item->$name : ''); ?><?php } ?></textarea>
            </div>
        </div>
    </div>
</div>