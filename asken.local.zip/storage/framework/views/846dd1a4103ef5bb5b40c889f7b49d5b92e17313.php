<?php $__env->startSection('app_content'); ?>

    <?php
    $seo_new = (object)[];
    $seo_new->title = html_entity_decode($get_cat->title).' | '.config('app.name');
    ?>

    <div class="goods">
        <div class="contain">
            <h1 class="title">
                <span>Каталог товаров</span>
                <button class="js_check_mobile"></button>
            </h1>
        </div>
        <?php if(count($cats)): ?>
            <form id="category_check">
                <div class="chech_head">
                    <div class="title_check">Выберите товар</div>
                    <button type="button" class="js_close_check"></button>
                </div>
                <div class="bn">
                    <select class="category_check_select">
                        <option value="0" selected disabled>Тип товара</option>
                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->url); ?>" <?php echo e(($c->url == $cat) ? 'selected' : ''); ?>><?php echo e($c->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <option disabled class="stub">...</option>
                    </select>
                </div>
                <?php if(count($subcat)): ?>
                    <div class="bn">
                        <select class="category_check_select">
                            <option value="0" selected disabled>Тип товара</option>
                            <?php $__currentLoopData = $subcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->url); ?>" <?php echo e(($s->url == $cat) ? 'selected' : ''); ?>><?php echo e($s->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option disabled class="stub">...</option>
                        </select>
                    </div>
                <?php endif; ?>
                <div class="found"><span>Найдено <?php echo e($goods->count()); ?> товаров</span></div>
            </form>
        <?php endif; ?>
        <div class="block">
            <div class="contain">
                <div class="elements js_elementsCat">
                    <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bn">
                            <a href="/goods_show/<?php echo e($item->url); ?>" class="good" style="background-image: url(<?php echo e(issetImg($item->image)); ?>)">
                                <div class="box">
                                    <div class="m_top">
                                        <div class="mobile_image" style="background-image: url(<?php echo e(issetImg($item->image)); ?>)"></div>
                                        <div class="rubber">
                                            <div class="text_content">
                                                <h2><?php echo e(str_limit($item->title, 40)); ?></h2>
                                                <div class="buy_elements">
                                                    <button type="button" class="buy js_buy" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                                    <button type="button" class="favourite js_favourite" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                                    <div class="link"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="m_bottom">
                                        <div class="buy_elements">
                                            <button type="button" class="buy js_buy" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                            <button type="button" class="favourite js_favourite" data-good_id="<?php echo e($item->id); ?>" onclick="return false"></button>
                                            <div class="link"></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo $__env->make('admin._input.paginator', [
                    'page' => $paginate_param['page'],
                    'total' => $paginate_param['total'],
                    'patch'=> null
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>