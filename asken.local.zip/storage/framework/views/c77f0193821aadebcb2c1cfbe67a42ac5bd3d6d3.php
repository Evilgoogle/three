<h2 class="card-inside-title"><?php echo e($label); ?> <?php echo e(isset($required) && $required ? '*' : ''); ?></h2>
<div class="row clearfix">
    <div class="col-sm-12">
        <div class="form-group">
            <div class="switch">
                <label><?php echo e($off); ?>

                    <input
                        type="checkbox"
                        id="<?php echo e($name); ?>"
                        name="<?php echo e($name); ?><?php echo e(isset($array) && $array ? '[]' : ''); ?>"
                        <?php echo e(isset($item->$name) && $item->$name ? 'checked' : ''); ?>

                        <?php echo e(empty($item) && isset($default) && $default ? 'checked' : ''); ?>

                        <?php echo e(isset($required) && $required ? 'required' : ''); ?>

                        <?php echo e(isset($array) && $array ? 'multiple' : ''); ?>

                        <?php echo e(isset($disabled) && $disabled ? 'disabled' : ''); ?>>
                    <span class="lever switch-col-blue"></span>
                <?php echo e($on); ?></label>
            </div>
        </div>
    </div>
</div>