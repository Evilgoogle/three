<?php $__env->startSection('admin_content'); ?>

    <input type="hidden" id="ajaxUrl" value="<?php echo e($info->url); ?>">
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <h2><?php echo e($info->head); ?></h2>
                    
                </div>
                <div class="body table-responsive">
                    <table class="table table-bordered table-striped  dataTable">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Имя</th>
                            <th>Статус</th>
                            <th>Опции</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="<?php echo e($item->id); ?>">
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->enable ? 'Обработано' : 'Не обработано'); ?></td>
                                <td>
                                    <a href="/admin/<?php echo e($info->url); ?>/edit/<?php echo e($item->id); ?>">Изменить</a> 
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>