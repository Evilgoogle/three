<?php $__env->startSection('app_content'); ?>

    <div id="none" style="display: none" class="about">
        <div class="contain">
            <img src="/images/logo_text.svg" alt="Asken" class="logo wow fadeIn" data-wow-duration="1.3s" data-wow-delay="0.5s" data-wow-offset="10">
            <div class="text_1 wow fadeIn" data-wow-duration="0.7s" data-wow-delay="0.3s" data-wow-offset="10"><?php echo $about->text_1; ?></div>
        </div>
        <div class="industries_block wow fadeInUp" data-wow-duration="0.7s" data-wow-delay="0.3s" data-wow-offset="10">
            <div class="contain">
                <?php $__currentLoopData = $main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/catalog/<?php echo e($item->url); ?>" class="bn">
                        <div class="rubber">
                            <div class="text"><?php echo e($item->title); ?></div>
                            <div class="icon"><?php echo file_get_contents(asset('/files/'.$item->icon)); ?></div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="contain wow fadeIn" data-wow-duration="1.3s" data-wow-delay="0.5s" data-wow-offset="10">
            <div class="text_2"><?php echo $about->text_2; ?></div>
            <div class="text_gray"><?php echo $about->textgray; ?></div>
        </div>
        <div class="mission wow fadeIn" data-wow-duration="1.3s" data-wow-delay="0.5s" data-wow-offset="10">
            <div class="head">
                <div class="line"></div>
                <div class="box">Миссия</div>
            </div>
            <div class="contain">
                Улучшить и развить поставки качественной продукции в различные отрасли экономики.
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>