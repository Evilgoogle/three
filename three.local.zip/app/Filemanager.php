<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Filemanager extends Model
{
    //
}
