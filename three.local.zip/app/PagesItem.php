<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PagesItem extends Model
{
    //
}
